
## DIGITAL FILTER NOTES 


### Z-Transform Derivation

When investigating the characteristics of a digital system, we use signal sampling, the z-transform is used. Consider a unit step function at t=0 which is sampled using a sampling interval of T.  The resultant signal is a series of pulses as shown below;


```R
y=seq(from=1,length=10,by=0)
x=1:10
plot.new()
plot.window(xlim = range(x),ylim = 0:1)
title(main = "Unit step function")
lines(x,y, type = 'h')
```



Note: The sampled signal shown in figure 1 could be the output from a DAC with No “hold” device. The pulse sequence shown in figure 1 can be mathematically represented by the series f’(k) where f’(k)= 1.δ(0), 1δ(t-T), 1.δ(t-2T), 1.δ(t-3T).., 1.δ(t-kT).(1) where k continues to ∞.

In eqn. (1) δ( ) represents the unit impulse function or “dirac-delta” function which is zero everywhere except when the argument is equal to zero. Note that, in digital control text books, the series equation represented by equation (1) is sometimes referred to as u(k).

A function f(t)  can be derived from the series f’(k) as follows:

f(t)= 1.δ(0), 1δ(t-T), 1.δ(t-2T), 1.δ(t-3T).., 1.δ(t-kT).. 	(2)
	
f(t) may also be written as 

∑_(k=0)^∞▒〖1.δ(t-kT)〗  	(3)

By invoking the “time shift theorem” (e.g. W. Bolton, “Laplace and z-transforms” Longman, 1998, page 6) the Laplace Transform of f(t) can be found as follows:
	L{f(t)}=1+ +e-2Ts +e-3Ts +e-4Ts +..+e-kTs to infinity	(4)
	If, in equation (4), we let z=eTs, then equation (4) can be rewritten as 
	L{f(t)}=F(z)=1+z-1 +z-2 +z-3 +z-4 +..+z-k to infinity	(5)
	F(z) is known as the z-transform.  The series in equation (5) is the z-transform of a unit step function (at t=0) which is sampled using interval T.
	In equation (5), the z-transform of the sampled unit step function is represented by an infinite series.  However, the expression for F(z) can be greatly simplified as follows:
	F(z)/z= z-z-2 +z-3 +z-4 +..+z-k to infinity	(6)
	Therefore F(z)-F(z)/z=1  F(z)(1-z1)=1 or F(z)=1/(1- z1) 
	Therefore F(z)=z/(z-1)	(7)
	The expression for the z-transform of a unit step (at t=0) given in equation (7) is the most convenient form for analyzing digital systems and is the form quoted in standard tables of z-transforms.
	Note that using a similar procedure, it is simple to show that for a sampled step function of magnitude M (at t=0), with a sampling interval T, F(z) is given by F(z)=M.z/(z-1)	(8)
Z-TRANSFORM OF A SAMPLED UNIT RAMP FUNCTION
	A unit ramp function sampled using sampling interval T will result in the following series of pulses below
	
	The pulse sequence f’(k) can be represented as
	f’(k)=0,T.δ(t-T),2T.δ(t-2T), 3T.δ(t-3T).., kT.δ(t-kT)
	or f(t)= ∑_(k=0)^∞▒〖kT.δ(t-kT)〗  	(3)
	Note that using a similar procedure, by series of transformation, a sampled ramp function of magnitude M (at t=0), with a sampling interval T, F(z) is given by F(z)=MTz/(z-1)2 	(8)
Z-TRANSFORM OF A SAMPLED EXPONENTIAL DECAY FUNCTION
	A unit ramp function sampled using sampling interval T will result in the following series of pulses below
	
	The pulse sequence f’(k) can be represented as
	f’(k)=1.δ(0),e-aT.δ(t-T), e-a2T.δ(t-2T), e-a3T.δ(t-3T).., e-akT.δ(t-kT)
	or f(t)= ∑_(k=0)^∞▒〖e^(-kT).δ(t-kT)〗  	(3)
	Note that using a similar procedure, by series of transformation, a sampled decaying exponential function of with a sampling interval T, F(z) is given by F(z)=z/(z-e-aT) 	(8)


### Z-transform by long division

The pulse sequence f'(k), from which a z-transform is derived, can also be obtained useing a long division as shown in the examples below:

#### Unit Step Function

For a unit step function (at t=0) $$ F(z)=\frac{z}{z-1} - - - - \dots (25) $$

Dividing the numerator of equation (25) by the denominator using long devision enables us to write F(z) as a series as shown below:

$$
\begin{array}{cccccccccccccc}
  & & 1 & + & z^{-1} & + & z^{-2} & + & z^{-3} & + & z^{-4} & + & ... \\ \hline 
  z-1 & \big) & z \\ 
  & & z & - & 1 \\ \hline
  & & & & 1 \\
  & & & & 1 & - & z^{-1} \\ \hline
  & & & & & & z^{-1} \\
  & & & & & & z^{-1} & - & z^{-2} \\ \hline
  & & & & & & & & z^{-2} \\
  & & & & & & & & z^{-2} & - & z^{-3} \\ \hline
  & & & & & & & & & & z^{-3} \\
\end{array}
$$

Thus $$ F(z)=1+ z^{-1}+ z^{-2}+ z^{-3}+ z^{-4} \dots - - - - \dots (26) $$
 

From equation (26) and using  the time shift function of the z operator, it is clear that the function f(t) from which F(z) is derived is given by
$$
f(t)=1.\delta(0)+1.\delta(t-T)+1.\delta(t-2T)+1.\delta(t-3T)+1.\delta(t-4T)+\dots - - - - \dots (27)
$$

The corresponding pulse sequence f'(k) is therefore given by
$$
f'(k)=1.\delta(0)+1.\delta(t-T)+1.\delta(t-2T)+1.\delta(t-3T)+1.\delta(t-4T)+\dots +1.\delta(t-kT) \dots  - - - - \dots (28)
$$  Where k continues to infinity



#### Unit Ramp Function

For a unit step function (at t=0) $$ F(z)=\frac{z}{z-1} - - - - \dots (25) $$

Dividing the numerator of equation (25) by the denominator using long devision enables us to write F(z) as a series as shown below:

$$
\begin{array}{cccccccccccccc}
  & & 1 & + & z^{-1} & + & z^{-2} & + & z^{-3} & + & z^{-4} & + & ... \\ \hline 
  z-1 & \big) & z \\ 
  & & z & - & 1 \\ \hline
  & & & & 1 \\
  & & & & 1 & - & z^{-1} \\ \hline
  & & & & & & z^{-1} \\
  & & & & & & z^{-1} & - & z^{-2} \\ \hline
  & & & & & & & & z^{-2} \\
  & & & & & & & & z^{-2} & - & z^{-3} \\ \hline
  & & & & & & & & & & z^{-3} \\
\end{array}
$$

Thus $$ F(z)=1+ z^{-1}+ z^{-2}+ z^{-3}+ z^{-4} \dots - - - - \dots (26) $$
 

From equation (26) and using  the time shift function of the z operator, it is clear that the function f(t) from which F(z) is derived is given by
$$
f(t)=1.\delta(0)+1.\delta(t-T)+1.\delta(t-2T)+1.\delta(t-3T)+1.\delta(t-4T)+\dots - - - - \dots (27)
$$

The corresponding pulse sequence f'(k) is therefore given by
$$
f'(k)=1.\delta(0)+1.\delta(t-T)+1.\delta(t-2T)+1.\delta(t-3T)+1.\delta(t-4T)+\dots +1.\delta(t-kT) \dots  - - - - \dots (27)
$$  Where k continues to infinity



### Filter-Transform Derivation

A digital filter has a z-transfer function (z-transform) of the form

[comment]: <> ((Y(z))/(X(z))=(a_0+a_1 z^(-1)+a_2 z^(-2)+a_3 z^(-3)+..)/(b_0+b_1 z^(-1)+b_2 z^(-2)+b_3 z^(-3)+..))

$$ \frac{Y(z)}{X(z)}=\frac{a_0+a_1 z^{-1}+a_2 z^{-2}+a_3 z^{-3}+..}{b_0+b_1 z^{-1}+b_2 z^{-2}+b_3 z^{-3}+..}  $$
where a<sub>0</sub>, a<sub>1</sub>, b<sub>0</sub>, b<sub>1</sub>, etc are constant coefficients (normally only the first few of these coefficients are non-zero), Y(z) is the z tranform associated with the output series y'(n) and X(z) is the z-transform associated with the input series x'(n)

Let us now suppose x'(n) is given by: $$ x'(n)=x(0)\delta(0), x(1)\delta(t-T),\dots,x(n)\delta(t-nT) - - - - \dots (1) $$

Let us suposse that a digital filter of the form
$$ \frac{Y(z)}{X(z)}=\frac{a_0+a_1 z^{-1}+a_2 z^{-2}+a_3 z^{-3}+..}{b_0+b_1 z^{-1}+b_2 z^{-2}+b_3 z^{-3}+..} - - - - \dots (2)$$

is applied to x'(n) to yield output series y'(n) where $$ y'(n)=y(0)\delta(0), y(1)\delta(t-T),\dots,y(n)\delta(t-nT) - - - - \dots (3) $$

we will now examine the reltionship between y'(n) and x'(n) as a result of the digital filtering process.
From equation (2) 
$$ Y(z)\{b_0+b_1 z^{-1}+b_2 z^{-2}\}=X(z)\{a_0+a_1 z^{-1}+a_2 z^{-2}\} - - - - \dots (4)$$

Once again, applying the time shift theorem on Y(z) and X(z) we have

$$
\begin{aligned}  
& b_{0}\{y(0)\delta(0)+y(1)\delta(t-T)+y(2)\delta(t-2T)+ \dots +y(n)\delta(t-nT) & +\dots\} \\ 
+ & b_{1}\{y(-1)\delta(0)+y(0)\delta(t-T)+y(1)\delta(t-2T)+ \dots +y(n-1)\delta(t-nT) & +\dots\} \\ 
+ & b_{2}\{y(-2)\delta(0)+y(-1)\delta(t-T)+y(0)\delta(t-2T)+ \dots +y(n-2)\delta(t-nT) & +\dots\} 
\end{aligned} 
=
\begin{aligned}  
& b_{0}\{x(0)\delta(0)+x(1)\delta(t-T)+x(2)\delta(t-2T)+ \dots +x(n)\delta(t-nT) & +\dots\} \\ 
+ & b_{1}\{x(-1)\delta(0)+x(0)\delta(t-T)+x(1)\delta(t-2T)+ \dots +x(n-1)\delta(t-nT) & +\dots\} \\ 
+ & b_{2}\{x(-2)\delta(0)+x(-1)\delta(t-T)+x(0)\delta(t-2T)+ \dots +x(n-2)\delta(t-nT) & +\dots\} 
\end{aligned} - - - - \dots (5)
$$

From equation (5) we may now write the folloing relationship between the nth terms on the lhs and rhs
$$ \{b_0 y(n)+b_1 y(n-1)+b_2 y(n-2) \}\delta(t-nT)=\{a_0 x(n)+a_1 x(n-1)+a_2 x(n-2) \}\delta(t-nT) - - - - \dots(6) $$

From equation (6) we may no infer the following expression for y(n) the nth term in the series y’(n) which occurs at t=nT (where T is the interval between successive terms in x’(n) and y’(n))
	$$ y(n)=\frac{1}{b_0}  \{a_0 x(n)+a_1 x(n-1)+a_2 x(n-2)-b_1 y(n-1)-b_2 y(n-2)\} - - - - \dots(7) $$

Equation (7) may appear complicated but all that it says is that the nth term y(n) (in the filtered output series y'(n), is made up of the nth, (n-1)st and (n-2)nd terms in the input series x'(n) the (n-1)st and (n-2)nd terms in y'(n) and the cefficients a<sub>0</sub>, a<sub>1</sub>, a<sub>2</sub> and b<sub>0</sub>, b<sub>1</sub>, b<sub>2</sub>

For a general digital filter with a transfer function of the form shown, we may say that the nth term y(n) of the output series y’(n) (the nth term occurring at t=nT) is given by:
$$ 
y(n)=\frac{1}{b_0}  \{a_0 x(n)+a_1 x(n-1)+a_2 x(n-2)\dots\}-\frac{1}{b_0} \{b_1 y(n-1)+b_2 y(n-2)+b_3 y(n-3)\dots\} - - - - \dots(8) 
$$

#### Example 1
a. Find the z-transform H(z) of the digital filter which is equivalent to the analog filte with the transfer function 
 $$ H_a(s)= \frac{1}{s+1} $$  
 What sampling interval T should be used with this digital filter?
 
b. For the digital filter in part (a) above find the relationship between the nth terms of the sampled input series x'(n) to the filter and the sampled output y'(n) from the filter.

c. Apply the digital filter to the continuous signal $ x(t)=1.cos(0.08*2\pi*t)+0.5cos(2*2\pi*t) $  (i.e. x(t) is made up of a cosine wave of amplitude 1 at a frequency of 0.08Hz added to another cosine wave 0.5 at a frequency of 2Hz.


#### Solution
(i) Given that $ H_a(s)= \frac{1}{\tau s+1}  where  $ $\tau=1 $.  

Therefore, from equation (11) we have that
$$ H(z)=\frac{Tz}{z-e^{-T}} - - - - .(14) $$
From equation (11a) we have
$$ T = \frac{\pi.(1)}{100}=0.0314s - - - - . (15) $$
Combining (14) and (15) gives
$$ H(z)=\frac{0.0314z}{z-e^{-0.0314}} - - - - .(16) $$

(ii) From equation (16) H(z) may also be written as
$$ H(z)=\frac{0.0314}{1-z^{-1}e^{-0.0314}} $$
with reference to equation (13) we may write
$$ \frac{Y(z)}{X(z)}=\frac{0.0314z}{1-z^{-1}e^{-0.0314}}  $$
By applying the time shift operator $ z^{-1} $ yields
$$ y(n) = 0.314x(n)+e^{-0.0314}y(n-1) $$
$$ y(n) = 0.314x(n)+0.9692y(n-1) - - - - .(17) $$

(iii) This part of the question will be accomplished from code.  Allow a 25 second long segment of the signal x(t) to be sampled using a sampling interval of T=0.0314 seconds to create the data series x'(n), which is input to the digital filter to create the output series y'(n).


```R
t=seq(from=0,to=25, by=pi/100)
x=seq(from=0,length=length(t),by=0)
y=seq(from=0,length=length(t),by=0)
for (i in 1:length(t)) {
    x[i]=cos(0.08*2*pi*t[i])+0.5*cos(2*2*pi*t[i])
  }
plot(t,x,pch="*")
y[1]=1
for (i in 2:length(t)) {
    j=i-1
    y[[i]]=0.314*x[i]+0.9692*y[j]
  }
plot(t,y)

```





It is clear that the component of x'(n) at 0.08Hz is passed relatively unattenuated by the digital filter.  However, the component of x'(n) at 2Hz is attenuated quite drammatically.  This result is expected because we created a digital filter equivalent to the analog filter $$ H_a(s)= \frac{1}{s+1} $$  The -3dB frequency of this analog filter is $f_{-3dB}=\frac{1}{2\pi\tau} (where \tau=1) $.  Therefore  $f_{-3dB}=0.159Hz$.  We would expect such an analogue filter to "pass" a signal at 0.08Hz and attenuate a signal at 2Hz.

### Digital Filter Bandwidth
•	Suppose we design an analogue low pass filter to separate a signal at frequency fsig from a noise at frequency fnoise.  We design a filter with a -3dB frequency f-3dB such that fsig<f-3dB<fnoise
•	The larger the fnoise compared with f-3dB for such an analogue low pass filter, the more the noise will be attenuated.
•	For a digital low pass filter however, we must ensure that the frequency of any noise component which must be eliminated is always less than the filter bandwidth.
•	Note that the filter bandwidth (in rads-1) is given by ω0=π/T 	(1)
•	Where T is the sampling interval. i.e. f0 =1/2T (f0 is bandwidth in Hz) 	(2)
•	Therefore we must ensure that ωnoise<ω0 or fnoise<f0 	(3)
•	for a digital low-pass filter
•	Since the sampling frequency ωs is given by ωs=2π/T (i.e. fs=1/T) equation (3) is equivalent to saying that for a digital low pass filter, the noise frequency must be less than one half of the sampling frequency.
•	The reason for this is due to “aliasing” – and we find that if the noise frequency is not less than the filter bandwidth then the noise may not be properly filtered out.

Suppose we design an analogue low pass filter to separate a signal at frequency fsig from a noise at frequency fnoise.  We design a filter with a -3dB frequency f-3dB such that fsig<f-3dB<fnoise
	The larger the fnoise compared with f-3dB for such an analogue low pass filter, the more the noise will be attenuated.
	For a digital low pass filter however, we must ensure that the frequency of any noise component which must be eliminated is always less than the filter bandwidth.
	Note that the filter bandwidth (in rads-1) is given by ω0=π/T 	(1)
	Where T is the sampling interval. i.e. f0 =1/2T (f0 is bandwidth in Hz) 	(2)
	Therefore we must ensure that ωnoise<ω0 or fnoise<f0 	(3)
	for a digital low-pass filter
	Since the sampling frequency ωs is given by ωs=2π/T (i.e. fs=1/T) equation (3) is equivalent to saying that for a digital low pass filter, the noise frequency must be less than one half of the sampling frequency.
	The reason for this is due to “aliasing” – and we find that if the noise frequency is not less than the filter bandwidth then the noise may not be properly filtered out.
	Consider the digital equivalent of the analogue low pass filter Ha(s)=1/(s+1).  For this analogue filter the bandwidth ω0 was given by 100/τ (where τ=1s) .
	Therefore ω0=100rads-1 (and f0=15.91Hz) 	(4)
	The sampling interval T is given by T=π/ω0 = 0.0314s 	(5)
	The z transform for the equivalent digital filter is given by 
	H(z)=0.0314z/(z-e^(-0.0314) ) 	(6)
	The relationship between the nth term of the sampled output series from the digital filter and the sampled input is given by
	y(n)=0.0314x(n)+0.9691y(n-1) 	(7)
	This digital filter will now be applied to the following 3 signals, all sampled using the sampling interval T=0.0314 seconds, giving the filter bandwidth f0=1/2T=15.91Hz
	Case 1
	x(t)=cos(0.08*2πt)+0.5cos(2*2πt)
	fsig = 0.08Hz
	fnoise=2Hz
	therefore fnoise<f0
	Case 2
	x(t)=cos(0.08*2πt)+0.5cos(10*2πt)
	fsig = 0.08Hz
	fnoise=10Hz
	therefore fnoise>f0
	Case 3
	x(t)=cos(0.08*2πt)+0.5cos(31*2πt)
	fsig = 0.08Hz
	fnoise=31Hz
	therefore fnoise>f0


```R
t=seq(from=0,to=25, by=pi/100)
x=seq(from=0,length=length(t),by=0)
y=seq(from=0,length=length(t),by=0)
for (i in 1:length(t)) {
    x[i]=cos(0.08*2*pi*t[i])+0.5*cos(2*2*pi*t[i])
  }
plot(t,x,pch="*")
y[1]=1
for (i in 2:length(t)) {
    j=i-1
    y[[i]]=0.314*x[i]+0.9692*y[j]
  }
plot(t,y)

```




3.14159265358979



	It is clear that for case 3 where fnoise>f0 the digital filter fails to eliminate the noise component.
	This problem is related to the fact that the frequency of the noise component in case 3 is 31Hz, whilst the sampling frequency fs=1/T = 31.85Hz
	We know that if the sampling frequency is less than twice the frequency of the signal being sampled, then the sampled signal will not be representative of the original signal.  Thus under-sampling leads to incorrect operation of the filter, aliasing.
	Note that the minimum sampling rate required to make sure that the sampled signal is “representative” of the original signal is known as the “Nyquist rate” fNY,R where
	fNY,R=2 * fmax and where fmax is the frequency of the highest frequency component being sampled.
	Rather confusingly, there is also a term known as the “Nyquist frequency” which is being defined as being one half of the sampling frequency.
